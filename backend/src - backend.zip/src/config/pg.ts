// src/config/pg.ts
import { Pool } from 'pg';
export const pg = new Pool({ connectionString: process.env.PG_URI });
