// backend/src/modules/auth/auth.controller.ts
import { Request, Response, NextFunction } from 'express';
import * as svc from './auth.service';

import { env } from '@/config/env';

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const { matricula } = req.body as { matricula: string };
    const data = await svc.loginByMatricula(String(matricula ?? ''));

    const estId = data?.user?.idestablecimiento;
    if (typeof estId === 'number' && env.disabledEstIds.has(estId)) {
      // No devolvemos token, solo mensaje claro
      return res.status(403).json({
        ok: false,
        message: 'Tu establecimiento no está habilitado. Contacta al administrador.',
      });
    }

    res.json({ ok: true, ...data });
  } catch (e: any) {
    if (e.status) return res.status(e.status).json({ ok: false, message: e.message });
    next(e);
  }
}

// opcional: endpoint para validar token y leer payload
export async function me(req: Request, res: Response) {
  // si luego agregas middleware de auth, aquí solo devolverías req.user
  res.json({ ok: true, message: 'todo ok (pendiente middleware)' });
}
