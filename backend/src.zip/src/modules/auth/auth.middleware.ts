// backend/src/modules/auth/auth.middleware.ts
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '@/config/env';

export interface JwtPayload {
  sub: number;    // id usuario
  est?: number;   // id establecimiento (si lo pones en el token)
  [k: string]: any;
}

export function verifyJWT(req: Request, res: Response, next: NextFunction) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ ok: false, message: 'No autorizado' });

  try {
    const payload = jwt.verify(token, env.jwtSecret) as JwtPayload;
    (req as any).user = payload;
    next();
  } catch {
    return res.status(401).json({ ok: false, message: 'Token inválido' });
  }
}
