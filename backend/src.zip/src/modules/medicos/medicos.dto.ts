// 📁 src/modules/establecimientos/establecimientos.dto.ts
// DTOs de entrada/salida validados con Zod: validamos al borde del sistema (controller)

