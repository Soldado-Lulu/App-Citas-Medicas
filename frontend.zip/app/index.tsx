import { Redirect } from 'expo-router';
import React from 'react';

export default function Index() {
  // 🔹 Siempre redirige al login de usuario
  return <Redirect href="/auth/login" />;
}
