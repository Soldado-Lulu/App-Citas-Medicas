// app/user/agenda/index.tsx
import React from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useEspecialidades } from '../../../src/hooks/useAgendaEspecialidad';
import { useAuth } from '../../../src/contexts/AuthContext';
import dayjs from 'dayjs';

const hhmm = (v?: string) => (v ? dayjs(v).format('HH:mm') : '--');

export default function AgendaHome() {
  const router = useRouter();

  // ⬇️ Tomamos el establecimiento del usuario logueado
  const { user } = useAuth();
  const idest = user?.idestablecimiento ?? 0;

  // ⬇️ Cargamos especialidades para ese establecimiento
  const { data, loading, error, buscar, setBuscar } = useEspecialidades(idest);

  // (Opcional) mensaje si no hay establecimiento definido en el usuario
  if (!idest) {
    return (
      <View style={{ flex: 1, padding: 16, gap: 12 }}>
        <Text style={{ fontSize: 16, color: '#b91c1c' }}>
          Tu usuario no tiene establecimiento asignado.
        </Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, padding: 16, gap: 12 }}>
      <Text style={{ fontSize: 22, fontWeight: '600' }}>Agendar por especialidad</Text>

      <TextInput
        placeholder="Buscar (nombre o sigla)…"
        value={buscar}
        onChangeText={setBuscar}
        style={{ borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 12 }}
      />

      {loading && <ActivityIndicator />}
      {error && <Text style={{ color: 'red' }}>{error}</Text>}

      <FlatList
        data={data}
        keyExtractor={(i) => String(i.idcuaderno)}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() =>
              router.push({
                pathname: '/user/agenda/[idcuaderno]',
                params: { idcuaderno: String(item.idcuaderno), idest: String(idest) },
              })
            }
            style={{
              padding: 14,
              borderRadius: 12,
              borderWidth: 1,
              borderColor: '#eee',
              marginBottom: 8,
            }}
          >
            <Text style={{ color: '#555' }}>
              {item.sigla} · {hhmm(item.cua_hora_inicio)}–{hhmm(item.cua_hora_fin)}
            </Text>
            <Text style={{ fontWeight: '600' }}>{item.nombre}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          !loading ? (
            <Text style={{ color: '#6b7280' }}>No se encontraron especialidades.</Text>
          ) : null
        }
      />
    </View>
  );
}
