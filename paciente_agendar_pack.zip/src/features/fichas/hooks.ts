import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fichasApi } from "./api";
import type { ConfirmarPayload } from "./types";

export function useEspecialidades(idest?: number) {
  return useQuery({ queryKey: ["especialidades", idest], enabled: !!idest, queryFn: () => fichasApi.especialidades(idest!), staleTime: 60_000 });
}
export function useDoctores(idest?: number, idesp?: number) {
  return useQuery({ queryKey: ["doctores", idest, idesp], enabled: !!idest && !!idesp, queryFn: () => fichasApi.doctoresPorEspecialidad(idest!, idesp!), staleTime: 60_000 });
}
export function useSlots(idest?: number, idpersonal?: number, fecha?: string) {
  return useQuery({ queryKey: ["slots", idest, idpersonal, fecha], enabled: !!idest && !!idpersonal && !!fecha, queryFn: () => fichasApi.slots(idest!, idpersonal!, fecha!), refetchInterval: 15_000 });
}
export function useConfirmarFicha() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: ConfirmarPayload) => fichasApi.confirmar(payload), onSuccess: () => { qc.invalidateQueries({ queryKey: ["slots"] }); qc.invalidateQueries({ queryKey: ["misCitas"] }); } });
}
export function useMisCitas(idpoblacionTitular?: number) {
  return useQuery({ queryKey: ["misCitas", idpoblacionTitular], enabled: !!idpoblacionTitular, queryFn: () => fichasApi.misCitas(idpoblacionTitular!) });
}
