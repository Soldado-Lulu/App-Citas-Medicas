import { View, Text, FlatList } from "react-native";
import { Page } from "@/src/ui/layout/Page";
import { useAuth } from "@/src/contexts/AuthContext";
import { useMisCitas } from "@/src/features/fichas/hooks";

export default function MisCitas() {
  const { user } = useAuth();
  const { data, isLoading } = useMisCitas(user?.idpoblacion_titular ?? user?.idpoblacion);
  return (
    <Page>
      <Text style={{ fontSize: 20, fontWeight: "800" }}>Mis citas</Text>
      {isLoading ? <Text>Cargando…</Text> : null}
      <FlatList
        data={data || []}
        keyExtractor={(c) => String(c.idcita)}
        renderItem={({ item }) => (
          <View style={{ padding: 12, borderWidth: 1, borderColor: "#e5e7eb", borderRadius: 12, marginTop: 8 }}>
            <Text style={{ fontWeight: "700" }}>{item.especialidad}</Text>
            <Text>{item.medico}</Text>
            <Text style={{ color: "#6b7280" }}>{item.fecha} · {item.hora}</Text>
            <Text style={{ marginTop: 4, fontWeight: "700", color: item.estado === "Confirmada" ? "#16a34a" : "#111827" }}>{item.estado}</Text>
          </View>
        )}
        ListEmptyComponent={!isLoading ? <Text>No tienes citas aún.</Text> : null}
      />
    </Page>
  );
}
