import { useState, useMemo } from "react";
import { View, Text, FlatList, TextInput } from "react-native";
import dayjs from "dayjs";
import { Page } from "@/src/ui/layout/Page";
import { Button } from "@/src/ui/primitives/Button";
import { EmptyState } from "@/src/ui/data/EmptyState";
import { useAuth } from "@/src/contexts/AuthContext";
import { useEspecialidades, useDoctores, useSlots, useConfirmarFicha } from "@/src/features/fichas/hooks";
import type { Slot } from "@/src/features/fichas/types";

export default function Agendar() {
  const { user } = useAuth();
  const idest = user?.idestablecimiento;
  const [idespecialidad, setIdEspecialidad] = useState<number | undefined>(undefined);
  const [idpersonalmedico, setIdPersonal] = useState<number | undefined>(undefined);
  const [fecha, setFecha] = useState(dayjs().format("YYYY-MM-DD"));
  const [idpoblacionSeleccionado, setIdPoblacion] = useState<number | undefined>(user?.idpoblacion);

  const { data: especialidades, isLoading: loadingEsp } = useEspecialidades(idest);
  const { data: doctores, isLoading: loadingDoc } = useDoctores(idest, idespecialidad);
  const { data: slots, isLoading: loadingSlots, refetch } = useSlots(idest, idpersonalmedico, fecha);

  const { mutate: confirmar, isPending: confirmando } = useConfirmarFicha();
  const disponible = useMemo(() => (slots || []).filter(s => s.estado === "Disponible"), [slots]);

  function onConfirmar(slot: Slot) {
    if (!idpoblacionSeleccionado) return;
    confirmar({ idfichaprogramada: slot.idfichaprogramada, idpoblacion: idpoblacionSeleccionado }, { onSuccess: () => refetch() });
  }

  return (
    <Page>
      <Text style={{ fontSize: 20, fontWeight: "800" }}>Agendar cita</Text>
      <Text style={{ color: "#6b7280" }}>Establecimiento: {user?.establecimiento ?? "—"}</Text>

      {/* 1) Especialidad */}
      <View style={{ marginTop: 16 }}>
        <Text style={{ fontWeight: "700", marginBottom: 8 }}>1) Selecciona especialidad</Text>
        <FlatList
          horizontal
          data={especialidades || []}
          keyExtractor={(e) => String(e.id)}
          contentContainerStyle={{ gap: 8 }}
          renderItem={({ item }) => (
            <Button label={item.nombre} variant={idespecialidad === item.id ? "primary" : "ghost"} onPress={() => { setIdEspecialidad(item.id); setIdPersonal(undefined); }} />
          )}
          ListEmptyComponent={loadingEsp ? <Text>Cargando…</Text> : <EmptyState title="Sin especialidades" />}
        />
      </View>

      {/* 2) Médico */}
      <View style={{ marginTop: 16 }}>
        <Text style={{ fontWeight: "700", marginBottom: 8 }}>2) Selecciona médico</Text>
        <FlatList
          horizontal
          data={doctores || []}
          keyExtractor={(e) => String(e.idpersonalmedico)}
          contentContainerStyle={{ gap: 8 }}
          renderItem={({ item }) => (
            <Button label={item.nombre_completo} variant={idpersonalmedico === item.idpersonalmedico ? "primary" : "ghost"} onPress={() => setIdPersonal(item.idpersonalmedico)} />
          )}
          ListEmptyComponent={loadingDoc ? <Text>Cargando…</Text> : <EmptyState title="Sin médicos" subtitle="No hay médicos para esta especialidad en el establecimiento." />}
        />
      </View>

      {/* 3) Fecha */}
      <View style={{ marginTop: 16 }}>
        <Text style={{ fontWeight: "700", marginBottom: 8 }}>3) Selecciona fecha</Text>
        <TextInput value={fecha} onChangeText={setFecha} placeholder="YYYY-MM-DD" style={{ borderWidth: 1, borderColor: "#e5e7eb", borderRadius: 10, padding: 10 }} />
      </View>

      {/* 4) Horarios */}
      <View style={{ marginTop: 16 }}>
        <Text style={{ fontWeight: "700", marginBottom: 8 }}>4) Selecciona hora</Text>
        <FlatList
          data={disponible}
          keyExtractor={(s) => String(s.idfichaprogramada)}
          numColumns={3}
          columnWrapperStyle={{ gap: 8 }}
          contentContainerStyle={{ gap: 8 }}
          renderItem={({ item }) => (<Button label={item.hora} onPress={() => onConfirmar(item)} loading={confirmando} />)}
          ListEmptyComponent={loadingSlots ? <Text>Cargando horas…</Text> : <EmptyState title="No hay horarios disponibles" onRetry={refetch} />}
        />
      </View>
    </Page>
  );
}
