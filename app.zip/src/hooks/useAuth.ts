// src/hooks/useAuth.ts
export { useAuth } from '../contexts/AuthContext';
